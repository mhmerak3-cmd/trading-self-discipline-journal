Trading & Self-Discipline Journal — ইনস্টলযোগ্য ওয়েব অ্যাপ

গুরুত্বপূর্ণ: PWA হিসেবে ইনস্টল করতে ফাইলগুলো HTTPS-এ হোস্ট করতে হবে। ZIP ফাইলটি সরাসরি খুললেই Install অপশন আসবে না।

সহজ পথ (GitHub Pages):
1. GitHub-এ লগইন/অ্যাকাউন্ট খুলুন।
2. New repository তৈরি করুন; নাম দিন trading-journal এবং Public রাখুন।
3. Add file → Upload files থেকে ZIP-এর ভেতরের সব ফাইল/ফোল্ডার আপলোড করুন (ZIP ফাইলটি নিজে নয়)।
4. Commit changes চাপুন।
5. Repository → Settings → Pages → Build and deployment-এ Deploy from a branch নির্বাচন করুন।
6. Branch হিসেবে main এবং folder হিসেবে /(root) বেছে Save চাপুন।
7. প্রকাশিত https://...github.io/trading-journal/ লিংকটি Chrome-এ খুলুন। প্রকাশ হতে কয়েক মিনিট লাগতে পারে।
8. Chrome-এর ⋮ মেনুতে “Install app” বা “Add to Home screen” চাপুন।
9. হোম স্ক্রিনে Trading Journal আইকন তৈরি হবে। এরপর আইকন থেকেই খুলবেন।

ডেটা ও ব্যাকআপ:
- রেকর্ড ফোনের ওই ব্রাউজারের Local Storage-এ থাকে; অনলাইনে আপনার অ্যাকাউন্টে সিঙ্ক হয় না।
- অ্যাপের Backup/Export দিয়ে নিয়মিত JSON ব্যাকআপ নিন। ব্রাউজারের ডেটা মুছলে রেকর্ড হারাতে পারে।
- নতুন ফোন/ব্রাউজারে রেকর্ড নিতে Export করা JSON ফাইলটি Import করুন।
- GitHub Pages-এ প্রকাশ করতে গেলে ZIP-এর ভেতরের ফাইলগুলো আপলোড করুন, ZIP ফাইলটি নয়।
