# TradeMind — Trading & Self-Discipline Journal

## What's included
- Mobile-first futuristic dashboard (Bangla + English)
- Trade timeline with entry reason, setup, P/L, R:R, emotion, mistakes, and lessons
- Mistake recurrence analysis and a 7/30-day local report
- Daily routine: breathing, plan, risk limits, food/water, exercise, learning, phone control, review
- Daily notes for sleep, food, exercise, and mindset
- Gemini AI Coach chat and period-based journal analysis
- Local browser storage, JSON backup/restore, CSV export
- Installable PWA shell when hosted on HTTPS (for example GitHub Pages)

## Start from a clean journal
This version uses a new storage key (`trademind_journal_v1`) and begins empty. It does not import any previous version's records.

## Publish on GitHub Pages (Android)
1. Download and extract this ZIP.
2. Open your GitHub repository `mhmerak3-cmd/trading-self-discipline-journal`.
3. Upload the files inside this folder to the repository root: `index.html`, `manifest.webmanifest`, `sw.js`, and `README.md`.
4. Commit the changes to the `main` branch.
5. In repository Settings → Pages, choose “Deploy from a branch”, select `main` and `/ (root)`, then Save.
6. Wait for the Pages URL to appear. Open that URL in Chrome.
7. In Chrome's menu, choose “Add to Home screen” or “Install app” if available.

If GitHub says `index.html` already exists, choose replace/overwrite when uploading the new version. Do not upload the ZIP itself as the site; upload its extracted files.

## Gemini setup
1. The API key previously pasted in chat should be considered exposed. Revoke it in Google AI Studio and create a new key.
2. Open the published site → Settings → Gemini API Setup.
3. Paste your new key and enter a model ID that is enabled in your Google AI Studio account. The default is `gemini-2.5-flash` as a placeholder/default; change it if that model is not available to your account.
4. For a quick test, leave “Save on this device” unchecked and tap “Test connection”. This keeps the key only in the current browser session.
5. If you enable “Save on this device”, the key is stored in local browser storage. This is convenient but not a secure vault: anyone who can inspect that browser profile or local storage may retrieve it.
6. Never commit an API key into GitHub or paste it into public code.

The app calls the Gemini API directly from the browser. This is suitable for personal experimentation but is not a secure production architecture: the API key can be extracted by a determined user and usage may incur quota/cost. A server-side proxy with authentication is safer if you later want stronger key protection.

## Important model note
“Gemini 3.6 Plus” could not be verified as a valid public Gemini API model ID. The model field is editable. Use the exact model ID currently shown as available to your account in Google AI Studio.

## Privacy and limitations
- Trade, habit, and notes data stays in this browser's local storage unless you export it or choose AI features.
- When you use AI analysis/chat, the selected journal context and prompt are sent to Google Gemini for processing.
- Clearing Chrome site data can erase local journal records. Download a JSON backup periodically.
- This app is a journaling and educational coaching tool, not financial advice and not a guaranteed signal system.


## Language selector
Use the selector at the top right to switch between বাংলা and English. The choice is saved in this browser. This version starts with a fresh journal storage key and does not import old records.


## Language selector
Use the selector at the top right to switch between বাংলা and English. The preference is saved in this browser. This fresh-start version uses its own storage key and does not import old records.
